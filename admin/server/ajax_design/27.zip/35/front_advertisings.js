var  front_advertisings = '<a href="http://my.ebay.com.au/ws/eBayISAPI.dll?AcceptSavedSeller&linkname=includenewsletter&sellerid=angelap88441&pageType=843">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/35//newsletter_subscribe-(1).jpg" title="Subscribe Newsletter" class="advertising-image">'+
'</a><a href="http://pages.ebay.com/paypal/ ">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/35//pay-safe-with-paypal-(1).png" title="Pay Safe with Paypal and Credit Cards" class="advertising-image">'+
'</a><a href="http://auspost.com.au/">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/35//Australia-Post.jpg" title="Australia Post" class="advertising-image">'+
'</a>';
