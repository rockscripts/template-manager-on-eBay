var  popoular_categories = '<div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Rigging gear" href="http://stores.ebay.com.au/Gear-HQ/rigging-gear-/_i.html?_fsub=4564481017">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/35//Rigging-gear-Gear-HQ-Store-eBay-Australia-%281%29.JPG" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Rigging gear</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Safety gear" href="http://stores.ebay.com.au/Gear-HQ/safety-gear-/_i.html?_fsub=4564482017">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/35//Safety-gear-Gear-HQ-Store-eBay-Australia.JPG" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Safety gear</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Tools" href="http://stores.ebay.com.au/Gear-HQ/tools-/_i.html?_fsub=4564479017">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/35//tools-Gear-HQ-Store-eBay-Australia-%281%29.JPG" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Tools</span>'+
'</div>'+
'</div>';
