document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://stores.ebay.com.au/Gear-HQ/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Gear-HQ/Shipping-and-Returns.html">Shipping and Returns</a></li>');
document.write('</ul>');
