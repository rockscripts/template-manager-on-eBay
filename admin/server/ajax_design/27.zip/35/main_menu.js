document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://feedback.ebay.com.au/ws/eBayISAPI.dll?ViewFeedback2&userid=angelap8844&ftab=AllFeedback">Feedbacks</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Gear-HQ/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Gear-HQ/Shipping-and-Returns.html">Shipping and Returns</a></li>');
document.write('<li><a href="http://contact.ebay.com.au/ws/eBayISAPI.dll?FindAnswers&frm=284&&requested=angelap8844&guest=1">Contact Us</a></li>');
document.write('</ul>');
