var twiter_url = "http://twitter.com/";
var facebook_url = "http://facebook.com/";
var youtube_url = "http://youtube.com/";
var printerest_url = "http://pinterest.com/";
var linkedin_url = "";
var google_url = "http://Google.com/";
var delicious_url = "";
