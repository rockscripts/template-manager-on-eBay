var center_widgets = ["featured listings"];
