var  featured_listings = '<div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/Beaver-B-Safe-Roofers-Safety-Harness-Kit-Contractors-Bag-BK061015-/261448197890?pt=AU_ISafety&hash=item3cdf86e702"> <img itemprop="image" title="Beaver B-Safe Roofers Safety Harness Kit In Contractors Bag-BK061015" src="http://fileshosting.rockscripts.org/files/store_design/featured/35//Beaver-B-Safe-Roofers-Safety-Harness-Kit-In-Contractors-Bag-BK061015-Gear-HQ-Store-eBay-Australia.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/Beaver-B-Safe-Roofers-Safety-Harness-Kit-Contractors-Bag-BK061015-/261448197890?pt=AU_ISafety&hash=item3cdf86e702"><h3 class="promotion-plan-title"><span itemprop="name">Beaver B-Safe Roofers Safety Harness Kit In Contractors Bag-BK061015</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 264.95</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/BLACK-RAT-10-PIECE-WINCH-4x4-RECOVERY-KIT-SNATCH-STRAP-SHACKLES-4WD-RESCUE-NEW-/261448197919?pt=AU_Car_Parts_Accessories&hash=item3cdf86e71f"> <img itemprop="image" title="BLACK RAT 10 PIECE WINCH 4x4 RECOVERY KIT SNATCH STRAP SHACKLES 4WD RESCUE NEW" src="http://fileshosting.rockscripts.org/files/store_design/featured/35//BLACK-RAT-10-PIECE-WINCH-4x4-RECOVERY-KIT-SNATCH-STRAP-SHACKLES-4WD-RESCUE-NEW-Gear-HQ-Store-eBay-Australia.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/BLACK-RAT-10-PIECE-WINCH-4x4-RECOVERY-KIT-SNATCH-STRAP-SHACKLES-4WD-RESCUE-NEW-/261448197919?pt=AU_Car_Parts_Accessories&hash=item3cdf86e71f"><h3 class="promotion-plan-title"><span itemprop="name">BLACK RAT 10 PIECE WINCH 4x4 RECOVERY KIT SNATCH STRAP SHACKLES 4WD RESCUE NEW</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 215.00</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/Bow-Shackle-Rated-WLL-3-2T-NEW-PACK-4-4x4-4wd-Lifting-/261448197883?pt=AU_Car_Parts_Accessories&hash=item3cdf86e6fb"> <img itemprop="image" title=" Mouse over image to zoom Have one to sell? Sell it yourself Details about  Bow Shackle Rated WLL 3.2T NEW PACK OF 4, 4x4, 4wd, Lifting " src="http://fileshosting.rockscripts.org/files/store_design/featured/35//Bow-Shackle-Rated-WLL-3.2T-NEW-PACK-OF-4%2C-4x4%2C-4wd%2C-Lifting--Gear-HQ-Store-eBay-Australia-.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/Bow-Shackle-Rated-WLL-3-2T-NEW-PACK-4-4x4-4wd-Lifting-/261448197883?pt=AU_Car_Parts_Accessories&hash=item3cdf86e6fb"><h3 class="promotion-plan-title"><span itemprop="name"> Mouse over image to zoom Have one to sell? Sell it yourself Details about  Bow Shackle Rated WLL 3.2T NEW PACK OF 4, 4x4, 4wd, Lifting </span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 39.95</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/Brand-New-6-x-MACK-B-DOUBLE-POLARIZED-SAFETY-SUN-GLASSES-/261448197879?pt=AU_ISafety&hash=item3cdf86e6f7"> <img itemprop="image" title="Brand New 6 x MACK B DOUBLE POLARIZED SAFETY  SUN GLASSES" src="http://fileshosting.rockscripts.org/files/store_design/featured/35//Brand-New-6-x-MACK-B-DOUBLE-POLARIZED-SAFETY--SUN-GLASSES-Gear-HQ-Store-eBay-Australia.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/Brand-New-6-x-MACK-B-DOUBLE-POLARIZED-SAFETY-SUN-GLASSES-/261448197879?pt=AU_ISafety&hash=item3cdf86e6f7"><h3 class="promotion-plan-title"><span itemprop="name">Brand New 6 x MACK B DOUBLE POLARIZED SAFETY  SUN GLASSES</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 174.95</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/PELTOR-Ear-Muff-H10A-Optime-SLC80-34dB-Class-5-Over-the-head-Earmuff-/261448197898?pt=AU_ISafety&hash=item3cdf86e70a"> <img itemprop="image" title="PELTOR Ear Muff H10A Optime SLC80 34dB Class 5+ (Over-the-head Earmuff)" src="http://fileshosting.rockscripts.org/files/store_design/featured/35//PELTOR-Ear-Muff-H10A-Optime-SLC80-34dB-Class-5%2B-%28Over-the-head-Earmuff%29-Gear-HQ-Store-eBay-Australia.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/PELTOR-Ear-Muff-H10A-Optime-SLC80-34dB-Class-5-Over-the-head-Earmuff-/261448197898?pt=AU_ISafety&hash=item3cdf86e70a"><h3 class="promotion-plan-title"><span itemprop="name">PELTOR Ear Muff H10A Optime SLC80 34dB Class 5+ (Over-the-head Earmuff)</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 43.75</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com.au/itm/RIggers-Gloves-12-PACK-MEDIUM-RIGGERS-GLOVES-PREMIUM-COW-SK-FREE-EXPRESS-POST-/261448197917?pt=AU_ISafety&hash=item3cdf86e71d"> <img itemprop="image" title="RIggers Gloves 12 PACK MEDIUM RIGGERS GLOVES PREMIUM COW SK. FREE EXPRESS POST!!" src="http://fileshosting.rockscripts.org/files/store_design/featured/35//RIggers-Gloves-12-PACK-MEDIUM-RIGGERS-GLOVES-PREMIUM-COW-SK.-FREE-EXPRESS-POST%21%21-Gear-HQ-Store-eBay-Australia.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com.au/itm/RIggers-Gloves-12-PACK-MEDIUM-RIGGERS-GLOVES-PREMIUM-COW-SK-FREE-EXPRESS-POST-/261448197917?pt=AU_ISafety&hash=item3cdf86e71d"><h3 class="promotion-plan-title"><span itemprop="name">RIggers Gloves 12 PACK MEDIUM RIGGERS GLOVES PREMIUM COW SK. FREE EXPRESS POST!!</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">AUD 69.95</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>';
