var  dynamic_categories = '<ul class=\'vertical blue\'>'+
'<li><a href="http://stores.ebay.com.au/Gear-HQ/rigging-gear-/_i.html?_fsub=4564481017">Rigging gear</a></li>'+
'<li><a href="http://stores.ebay.com.au/Gear-HQ/tools-/_i.html?_fsub=4564479017">Tools</a></li>'+
'<li><a href="http://stores.ebay.com.au/Gear-HQ/safety-gear-/_i.html?_fsub=4564482017">Safety gear</a></li>'+
'<li><a href="http://stores.ebay.com.au/Gear-HQ/other-/_i.html?_fsub=1">Other</a></li>'+
'</ul>';
