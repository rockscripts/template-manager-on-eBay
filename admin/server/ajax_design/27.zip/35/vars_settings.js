var store_name = "Gear HQ";
var store_id = "angelap8844";
var store_url = "http://stores.ebay.com.au/Gear-HQ";
var store_phone = "";
var currency = "AUD";
var hosting_url = "http://hosting.rockscripts.org/35";
