var center_widgets = ["custom rich text","featured listings","popular categories"];
