var left_widgets = ["store categories","advertising","image & video slider","popular categories"];
