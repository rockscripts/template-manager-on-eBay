var  welcome_text = '<div class="center-banners-content">'+
'<div class="left banner-center banner-central banner-return">'+
'<img alt="" src="http://fileshosting.rockscripts.org/files/upload/35/images/banner-4-238x115.png" /></div>'+
'<div class="left banner-center banner-central banner-secure">'+
'<img alt="" src="http://fileshosting.rockscripts.org/files/upload/35/images/banner-3-238x115.png" /></div>'+
'<div class="left banner-center banner-central banner-postage">'+
'<img alt="" src="http://fileshosting.rockscripts.org/files/upload/35/images/banner-2-238x115.png" /></div>'+
'<div class="left banner-center banner-central banner-lowprice">'+
'<img alt="" src="http://fileshosting.rockscripts.org/files/upload/35/images/banner-1-238x115.png" /></div>'+
'</div>'+
'<div>'+
'</div>';
