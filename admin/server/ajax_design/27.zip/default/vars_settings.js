var store_name = "";
var store_id = "";
var store_url = "";
var store_phone = "";
var currency = "";
