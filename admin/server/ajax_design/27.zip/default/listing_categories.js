var  dynamic_categories = '<ul class="vertical blue">'+
'<li><a href="javascript:void();">Store has not categories</a></li>';
