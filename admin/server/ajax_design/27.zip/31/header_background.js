document.write('<img src="http://fileshosting.rockscripts.org/files/store_design/general_images/31//alpha-spaceman-store-on-eBay.png"  class="img-responsive">');
