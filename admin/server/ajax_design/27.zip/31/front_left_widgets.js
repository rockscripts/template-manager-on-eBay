var left_widgets = ["store categories","featured listings"];
