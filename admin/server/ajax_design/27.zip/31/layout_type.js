var layout_type = 2;
