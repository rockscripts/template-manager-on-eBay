var  dynamic_categories = '<ul class="vertical blue">'+
'<li><a href="http://stores.ebay.com/Alpha-Spaceman/other-/_i.html?_fsub=1">Other</a></li>'+
'<li><a href="http://stores.ebay.com/Alpha-Spaceman/hats-/_i.html?_fsub=11810796018">Hats</a></li>'+
'<li><a href="http://stores.ebay.com/Alpha-Spaceman/t-shirts-/_i.html?_fsub=11810797018">T shirts</a></li>'+
'<li><a href="http://stores.ebay.com/Alpha-Spaceman/jeans-/_i.html?_fsub=11810798018">Jeans</a></li>'+
'</ul>';
