document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://stores.ebay.com/Alpha-Spaceman/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.com/Alpha-Spaceman/Shipping-and-Returns.html">Shipping and Returns</a></li>');
document.write('</ul>');
