var  featured_listings = '<div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com/itm/Diamond-Supply-Co-OG-Script-Kneehigh-Sock-Orange-Yellow-/231188318456?pt=US_Men_s_Socks&hash=item35d3e5c8f8"> <img itemprop="image" title="Diamond Supply Co. OG Script Kneehigh Sock" src="http://fileshosting.rockscripts.org/files/store_design/featured/31//thumb-%281%29.jpeg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com/itm/Diamond-Supply-Co-OG-Script-Kneehigh-Sock-Orange-Yellow-/231188318456?pt=US_Men_s_Socks&hash=item35d3e5c8f8"><h3 class="promotion-plan-title"><span itemprop="name">Diamond Supply Co. OG Script Kneehigh Sock</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">USD 11.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://cgi.ebay.com/ws/eBayISAPI.dll?ViewItem&item=231188365488"> <img itemprop="image" title="Diamond Supply Co, High Cut Argyle Socks" src="http://fileshosting.rockscripts.org/files/store_design/featured/31//IMG_8090-01.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://cgi.ebay.com/ws/eBayISAPI.dll?ViewItem&item=231188365488"><h3 class="promotion-plan-title"><span itemprop="name">Diamond Supply Co, High Cut Argyle Socks</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">USD 11.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>';
