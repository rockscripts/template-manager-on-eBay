var store_name = "Alpha Spaceman";
var store_id = "alpha_spaceman";
var store_url = "http://stores.ebay.com/alphaspaceman";
var store_phone = "";
var currency = "USD";
var hosting_url = "http://hosting.rockscripts.org/31";
