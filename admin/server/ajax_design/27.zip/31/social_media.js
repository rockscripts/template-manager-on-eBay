var twiter_url = "";
var facebook_url = "https://www.facebook.com/pages/Alpha-Spaceman/670910419622194";
var youtube_url = "";
var printerest_url = "";
var linkedin_url = "";
var google_url = "";
var delicious_url = "";
