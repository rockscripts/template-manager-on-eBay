var right_widgets = ["new arrivals","newsletter"];
