document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://feedback.ebay.com/ws/eBayISAPI.dll?ViewFeedback2&userid=alpha_spaceman&ftab=AllFeedback">Feedbacks</a></li>');
document.write('<li><a href="http://stores.ebay.com/Alpha-Spaceman/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.com/Alpha-Spaceman/Shipping-and-Returns.html">Shipping and Returns</a></li>');
document.write('<li><a href="http://contact.ebay.co.uk/ws/eBayISAPI.dll?FindAnswers&frm=284&&requested=alphaspaceman&guest=1">Contact Us</a></li>');
document.write('</ul>');
