var  arrivals_listings = '<div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com/itm/Hundreds-Swish-Snapback-Cap-navy-Free-shipping-/231188287291?pt=US_Hats&hash=item35d3e54f3b"> <img itemprop="image" title="The Hundreds Swish Snapback Cap" src="http://fileshosting.rockscripts.org/files/store_design/arrivals/31//the-2.jpeg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com/itm/Hundreds-Swish-Snapback-Cap-navy-Free-shipping-/231188287291?pt=US_Hats&hash=item35d3e54f3b"><h3 class="promotion-plan-title"><span itemprop="name">The Hundreds Swish Snapback Cap</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">USD 14.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.com/itm/331161043088?ssPageName=STRK:MESELX:IT&_trksid=p3984.m1555.l2649"> <img itemprop="image" title="The Hundreds Swish Snapback Cap" src="http://fileshosting.rockscripts.org/files/store_design/arrivals/31//hat1.jpeg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.com/itm/331161043088?ssPageName=STRK:MESELX:IT&_trksid=p3984.m1555.l2649"><h3 class="promotion-plan-title"><span itemprop="name">The Hundreds Swish Snapback Cap</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">USD 14.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>';
