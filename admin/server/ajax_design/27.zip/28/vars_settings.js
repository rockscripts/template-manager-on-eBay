var store_name = "United Lighting Store";
var store_id = "unitedlighting";
var store_url = "http://stores.ebay.co.uk/unitedlightingstore";
var store_phone = "";
var currency = "GBP";
var hosting_url = "http://hosting.rockscripts.org/28";
