document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://stores.ebay.co.uk/United-Lighting-Store/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.co.uk/United-Lighting-Store/Feedbacks.html">Feedbacks</a></li>');
document.write('</ul>');
