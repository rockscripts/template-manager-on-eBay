var center_widgets = ["tabs"];
