document.write('<a href="" class="store-home-url"><img class="logo store-home-url" src="http://fileshosting.rockscripts.org/files/store_design/logos/28//logo.png" /></a>');
