var  dynamic_categories = '<ul class=\'vertical blue\'>'+
'<li><a href="http://stores.ebay.co.uk/United-Lighting-Store/ceiling-lights-/_i.html?_fsub=614024719">Ceiling lights</a></li>'+
'<li><a href="http://stores.ebay.co.uk/United-Lighting-Store/bathroom-lights-/_i.html?_fsub=614024619">Bathroom lights</a></li>'+
'<li><a href="http://stores.ebay.co.uk/United-Lighting-Store/other-/_i.html?_fsub=1">Other</a></li>'+
'</ul>';
