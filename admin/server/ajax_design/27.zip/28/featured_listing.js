var  featured_listings = '<div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/Lights-Aspen-Cube-Chrome-Bathroom-Wall-Lights-/300977307082?pt=UK_Home_Garden_Wall_Lights&hash=item4613a53dca"> <img itemprop="image" title="Lights Aspen Cube Chrome Bathroom Wall Lights" src="http://fileshosting.rockscripts.org/files/store_design/featured/28//Lights-Aspen-Cube-Chrome-Bathroom-Wall-Lights.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/Lights-Aspen-Cube-Chrome-Bathroom-Wall-Lights-/300977307082?pt=UK_Home_Garden_Wall_Lights&hash=item4613a53dca"><h3 class="promotion-plan-title"><span itemprop="name">Lights Aspen Cube Chrome Bathroom Wall Lights</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 17.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/Designer-Ceiling-light-/300977389932?pt=UK_HomeGarden_Lighting_Lamps_Lighting_SM&hash=item4613a6816c"> <img itemprop="image" title="Designer Ceiling Light" src="http://fileshosting.rockscripts.org/files/store_design/featured/28//Designer-Ceiling-light.JPG"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/Designer-Ceiling-light-/300977389932?pt=UK_HomeGarden_Lighting_Lamps_Lighting_SM&hash=item4613a6816c"><h3 class="promotion-plan-title"><span itemprop="name">Designer Ceiling Light</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 34.99</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>';
