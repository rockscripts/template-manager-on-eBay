var  tab_ontent = '<div id="js-tab-content-guarantee" class="tab_content">'+
'<div>'+
'<p>'+
'<u><strong>14 Day Guarantee</strong></u></p>'+
'<p>'+
'When you buy from United Lighting you buy with confidence as we offer the highest possible quality, <b>Guaranteed</b>. We offer a 14 day no quibble returns guarantee on all our listings. We want you to have peace of mind when buying from us.</p>'+
'<p>'+
'All products we supply have been manufactured to British and European standards. We provide as standard a 12 month warranty on all of our products. If any product we supply fails due to fault (manufacturing defect) we will provide you with the appropriate remedy e.g. repair, replacement or refund.</p>'+
'<p>'+
'United Lighting <i>want you to be completely happy.</i></p>'+
'<p>'+
'</p>'+
'</div>'+
'<div>'+
'</div>'+
'</div><div id="js-tab-content-feedbacks" class="tab_content">'+
'<h3>'+
'Feedbacks</h3>'+
'<div>'+
'<p>'+
'We work very hard to <strong>exceed</strong> your expectations.In the unlikely event due to circumstances outside our control, sometimes things can happen. We will always go out of our way to fix what ever may arise.</p>'+
'<p>'+
'We will always leave Positive Feedback for you as soon as payment is received and hope that if everything has been to your satisfaction then you will take a moment to do the same for us.</p>'+
'</div>'+
'</div><div id="js-tab-content-about-us" class="tab_content">'+
'<p>'+
'We have over 35 years continuous experience in the lighting industry. As a purchaser of our goods you can expect to receive a trusted and reliable service, and be assured that all our products meet UK and European lighting regulations.</p>'+
'</div><div id="js-tab-content-delivery-infomation" class="tab_content">'+
'<p>'+
'We pride ourselves on having the Best Customer Service and we want you to have your Brand New Item(s) as fast as possible. That\'s why we will ship all orders within 1 business day of receiving cleared funds. Making your experience Fast and Hassel Free. We use rapid courier delivery service that can be tracked online for most of our listings.</p>'+
'<h2>'+
'Returns Policy</h2>'+
'<p>'+
'Accepted, Most Buy It Now purchases are protected by the Distance Selling Regulations, which allow you to cancel the purchase within seven working days after the day you receive the item. All returned items must be undamaged.</p>'+
'<h2>'+
'Postal Policy</h2>'+
'<p>'+
'Postage to the UK is free. We will post to Europe but the purchaser will have to contact us for a quotation for their area. You will have to pay this delivery charge to your country</p>'+
'</div>';
