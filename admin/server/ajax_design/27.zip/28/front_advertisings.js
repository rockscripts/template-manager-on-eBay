var  front_advertisings = '<a href="http://pages.ebay.com/help/pay/methods.html">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/28//pay-safe-with-paypal.png" title="Pay Safe" class="advertising-image">'+
'</a><a href="javascript:void(0);">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/28//paypal-security.png" title="Security" class="advertising-image">'+
'</a>';
