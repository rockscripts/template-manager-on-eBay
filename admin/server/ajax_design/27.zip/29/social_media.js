var twiter_url = "https://twitter.com/bearingshopuk";
var facebook_url = "https://www.facebook.com/BearingShopUK";
var youtube_url = "http://www.youtube.com/user/BearingShopUK";
var printerest_url = "http://gb.pinterest.com/bearingshopuk/";
var linkedin_url = "";
var google_url = "https://plus.google.com/107822323243017009526/posts";
var delicious_url = "";
