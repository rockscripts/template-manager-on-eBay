var  welcome_text = '<p>'+
'<span style="color: #006db5; font-size: large;">Bearing Shop UK, at your service</span></p>'+
'<div class="bshomeparagraph">'+
'<p align="justify" class="bshomeparagraphcontent">'+
'<span style="font-size: small;">If you need machine elements, particularly bearings, then your search is over. As the one stop bearing shop in the UK we pretty much have everything you could possible need for your machines or projects. Whether for manufacturing or replacement purposes, we have all kinds of parts available for a wide variety of applications. They have been carefilly selected from high-quality manufacturers, around the world.</span></p>'+
'<p align="justify" class="bshomeparagraphcontent">'+
'<span style="font-size: small;">To start your search, browse through our extensive products menu. If you are having trouble locating a specific size or if the part your require is eluding you, simply complete the online search form and we will do the looking for you.</span></p>'+
'</div>'+
'<div>'+
'</div>';
