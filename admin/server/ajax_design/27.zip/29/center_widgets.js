var center_widgets = ["popular categories"];
