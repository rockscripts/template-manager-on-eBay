 var front_design_option_is_active_listings_on_front = 'OFF';
 var front_design_option_number_listings_on_front = '12';
