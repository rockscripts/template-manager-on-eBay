var store_name = "BearingShopUK";
var store_id = "bearingshopuk-eb";
var store_url = "http://stores.ebay.co.uk/bearingshopuk";
var store_phone = "";
var currency = "GBP";
var hosting_url = "http://hosting.rockscripts.org/29";
