var center_widgets = ["image & video slider","custom rich text","popular categories"];
