var  featured_listings = '<div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/6303-C3-SKF-Metric-Ball-Bearing-/141111239495"> <img itemprop="image" title=" Have one to sell? Sell it yourself Details about  6303-C3 - SKF Metric Ball Bearing" src="http://fileshosting.rockscripts.org/files/store_design/featured/29//Have-one-to-sell-Sell-it-yourself-Details-about--6303-C3---SKF-Metric-Ball-Bearing.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/6303-C3-SKF-Metric-Ball-Bearing-/141111239495"><h3 class="promotion-plan-title"><span itemprop="name"> Have one to sell? Sell it yourself Details about  6303-C3 - SKF Metric Ball Bearing</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 4.30</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/3-16-Steel-Balls-/140980851500?pt=LH_DefaultDomain_3&hash=item20d31d132c"> <img itemprop="image" title="Cycle Bearing  .3/16" Steel Balls" src="http://fileshosting.rockscripts.org/files/store_design/featured/29//Cycle-Bearing--316-Steel-Balls.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/3-16-Steel-Balls-/140980851500?pt=LH_DefaultDomain_3&hash=item20d31d132c"><h3 class="promotion-plan-title"><span itemprop="name">Cycle Bearing  .3/16" Steel Balls</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 1.20</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/61800-2RS-/140980851513?pt=LH_DefaultDomain_3&hash=item20d31d1339"> <img itemprop="image" title="Cycle Bearing  61800-2RS " src="http://fileshosting.rockscripts.org/files/store_design/featured/29//Cycle-Bearings--61803-2RS.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/61800-2RS-/140980851513?pt=LH_DefaultDomain_3&hash=item20d31d1339"><h3 class="promotion-plan-title"><span itemprop="name">Cycle Bearing  61800-2RS </span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 4.08</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/OS22X42X6mm-R23-Metric-Oilseal-/141122207839"> <img itemprop="image" title="OS22X42X6mm R23 Metric Oilseal" src="http://fileshosting.rockscripts.org/files/store_design/featured/29//OS22X42X6mm-R23-Metric-Oilseal.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/OS22X42X6mm-R23-Metric-Oilseal-/141122207839"><h3 class="promotion-plan-title"><span itemprop="name">OS22X42X6mm R23 Metric Oilseal</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 1.89</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>  <div class="promotion-plan"  itemscope itemtype="http://data-vocabulary.org/Product">'+
'<div  class="promotion-plan-image">'+
'<a href="http://www.ebay.co.uk/itm/320-28X-Q-SKF-Metric-Taper-Bearing-/141111166254"> <img itemprop="image" title="320/28X/Q SKF Metric Taper Bearing" src="http://fileshosting.rockscripts.org/files/store_design/featured/29//32028XQ-SKF-Metric-Taper-Bearing.jpg"></a>'+
'</div>'+
'<div  class="promotion-plan-info">'+
'<a href="http://www.ebay.co.uk/itm/320-28X-Q-SKF-Metric-Taper-Bearing-/141111166254"><h3 class="promotion-plan-title"><span itemprop="name">320/28X/Q SKF Metric Taper Bearing</span></h3></a>'+
'<div class="promotion-plan-price">'+
'<div  class="left">'+
'<span class="price-inner">Price:  <span class="price-value"  itemprop="price">GBP 11.75</span></span>'+
'</div>'+
'<div class="right hidden-xs">'+
'<a href="#"><div class="shop-now-button-small" title="Shop Now"></div></a>'+
'</div>'+
'</div>'+
'</div>'+
'</div>';
