var  popoular_categories = '<div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Ball Bearings" href="http://stores.ebay.co.uk/BearingShopUK/Ball-Bearings-10-55mm-Bore-/_i.html?_fsub=4580655011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Ball-bearings-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Ball Bearings</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Oil Impregnated Bushes" href="http://stores.ebay.co.uk/BearingShopUK/Oilite-Bushes-/_i.html?_fsub=5100942011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Oil-Impregnated-Bushes-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Oil Impregnated Bushes</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Vee Belt Pulleys" href="http://stores.ebay.co.uk/BearingShopUK/V-Belt-Pulleys-/_i.html?_fsub=4587867011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Vee-Belt-Pulleys-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Vee Belt Pulleys</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Taperlock Bushes" href="http://stores.ebay.co.uk/BearingShopUK/Taperlock-Bushes-/_i.html?_fsub=4587840011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Taperlock-Bushes-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Taperlock Bushes</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Glacier Bushes" href="http://stores.ebay.co.uk/BearingShopUK/Glacier-Bushes-/_i.html?_fsub=5147076011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Glacier-Bushes-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Glacier Bushes</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Gates Polyflex" href="http://stores.ebay.co.uk/BearingShopUK/Gates-Polyflex-/_i.html?_fsub=4580890011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Gates-Polyflex-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Gates Polyflex</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Rod End Bearings" href="http://stores.ebay.co.uk/BearingShopUK/Rod-Ends-/_i.html?_fsub=4587827011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Rod-End-Bearings-bearings-shop-uk-eBay.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Rod End Bearings</span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Mower Belts " href="http://stores.ebay.co.uk/BearingShopUK/Mower-Belts-/_i.html?_fsub=4580834011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//Mower-Belts--bearings-shop-uk-eBay-%281%29.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Mower Belts </span>'+
'</div>'+
'</div><div class="rc-box">'+
'<div class="rc-image">'+
'<a title="SKF Speedi Sleeves " href="http://stores.ebay.co.uk/BearingShopUK/SKF-Speedi-Sleeves-/_i.html?_fsub=5100938011&_sid=126180801&_trksid=p4634.c0.m322">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/29//SKF-Speedi-Sleeves-bearings-shop-uk-eBay-.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>SKF Speedi Sleeves </span>'+
'</div>'+
'</div>';
