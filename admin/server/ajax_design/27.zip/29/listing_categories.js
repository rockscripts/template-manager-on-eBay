var  dynamic_categories = '<ul class="vertical blue">'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/glacier-bushes-/_i.html?_fsub=5147076011">Glacier bushes</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/v-belt-pulleys-/_i.html?_fsub=4587867011">V belt pulleys</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/keysteel-/_i.html?_fsub=4587832011">Keysteel</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/taperlock-bushes-/_i.html?_fsub=4587840011">Taperlock bushes</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/3535-/_i.html?_fsub=4587859011">3535</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/5050-/_i.html?_fsub=4587861011">5050</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/4040-/_i.html?_fsub=4587860011">4040</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/3525-/_i.html?_fsub=4587858011">3525</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/3030-/_i.html?_fsub=4587857011">3030</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/3020-/_i.html?_fsub=4587856011">3020</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/2525-/_i.html?_fsub=4587855011">2525</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1615-/_i.html?_fsub=4587849011">1615</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/2012-/_i.html?_fsub=4587850011">2012</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/2517-/_i.html?_fsub=4587854011">2517</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1310-/_i.html?_fsub=4587847011">1310</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1610-/_i.html?_fsub=4587848011">1610</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1210-/_i.html?_fsub=4587843011">1210</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1215-/_i.html?_fsub=4587844011">1215</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1108-/_i.html?_fsub=4587842011">1108</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/1008-/_i.html?_fsub=4587841011">1008</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/couplings-/_i.html?_fsub=4587830011">Couplings</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/hrc-couplings-/_i.html?_fsub=4587831011">Hrc couplings</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/belts-/_i.html?_fsub=4580654011">Belts</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/nutlink-/_i.html?_fsub=4587838011">Nutlink</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/automotive-fan-belts-/_i.html?_fsub=4580891011">Automotive fan belts</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/gates-polyflex-/_i.html?_fsub=4580890011">Gates polyflex</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/mower-belts-/_i.html?_fsub=4580834011">Mower belts</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/kevlar-belts-/_i.html?_fsub=4580833011">Kevlar belts</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/hexagonal-/_i.html?_fsub=4583776011">Hexagonal</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/5l-section-/_i.html?_fsub=4583775011">5l section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/4l-section-/_i.html?_fsub=4583774011">4l section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/3l-section-/_i.html?_fsub=4583773011">3l section</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/v-belts-/_i.html?_fsub=4580747011">V belts</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/z-section-/_i.html?_fsub=5497262011">Z section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/a-section-/_i.html?_fsub=5497263011">A section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/b-section-/_i.html?_fsub=5497264011">B section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/c-section-/_i.html?_fsub=5497265011">C section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/d-section-/_i.html?_fsub=5497266011">D section</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/wedge-belts-/_i.html?_fsub=4580793011">Wedge belts</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/bearings-/_i.html?_fsub=4580653011">Bearings</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/ball-bearings-(>60mm-bore)-/_i.html?_fsub=5100936011">Ball bearings (>60mm bore)</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/skf-high-temp-bearings-/_i.html?_fsub=5100935011">Skf high temp bearings</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/skf-metric-tapers-/_i.html?_fsub=5100934011">Skf metric tapers</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/thin-section-/_i.html?_fsub=4587828011">Thin section</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/quadpower-/_i.html?_fsub=4587839011">Quadpower</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/miniature-/_i.html?_fsub=4587826011">Miniature</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/rod-ends-/_i.html?_fsub=4587827011">Rod ends</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/ball-bearings-(10-55mm-bore)-/_i.html?_fsub=4580655011">Ball bearings (10-55mm bore)</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/cycle-bearings-/_i.html?_fsub=4587825011">Cycle bearings</a></li>'+
'</ul>'+
'</li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/other-/_i.html?_fsub=1">Other</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/skf-bearing-heaters-/_i.html?_fsub=5100937011">Skf bearing heaters</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/skf-speedi-sleeves-/_i.html?_fsub=5100938011">Skf speedi sleeves</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/circlips-/_i.html?_fsub=5100940011">Circlips</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/oilseals-/_i.html?_fsub=5100941011">Oilseals</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/oilite-bushes-/_i.html?_fsub=5100942011">Oilite bushes</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/pulleys-&-bushes-/_i.html?_fsub=5498272011">Pulleys & bushes</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/seals-&-clips-/_i.html?_fsub=5498342011">Seals & clips</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/o\'rings-/_i.html?_fsub=5498381011">O\'rings</a>'+
'<ul>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/packs-of-10-/_i.html?_fsub=5498397011">Packs of 10</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/packs-of-50-/_i.html?_fsub=5498398011">Packs of 50</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/packs-of-100-/_i.html?_fsub=5498399011">Packs of 100</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/packs-of-500-/_i.html?_fsub=5498547011">Packs of 500</a></li>'+
'<li><a href="http://stores.ebay.co.uk/BearingShopUK/packs-of-1000-/_i.html?_fsub=5498548011">Packs of 1000</a></li>'+
'</ul>'+
'</li>'+
'</ul>'+
'</li>'+
'</ul>';
