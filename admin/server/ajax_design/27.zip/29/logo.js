document.write('<a href="" class="store-home-url"><img class="logo store-home-url" src="http://fileshosting.rockscripts.org/files/store_design/logos/29//logo-%281%29.png" /></a>');
