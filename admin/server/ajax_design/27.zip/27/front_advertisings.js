var  front_advertisings = '<a href="http://pages.ebay.com/help/pay/methods.html">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/27//secure-payment-by-paypal-alchemysuiting.jpg" title="Secure Payment" class="advertising-image">'+
'</a><a href="http://stores.ebay.com.au/AlchemySuiting/custom-suits-/_i.html?_fsub=11522889018">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/home_design_advertisements/27//suits-and-blazers.png" title="Suits & Blazers" class="advertising-image">'+
'</a>';
