var  welcome_text = '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Custom text widget is active but has not text to show..';
