document.write('<ul class=\'nav navbar-nav\'>');
document.write('<li><a href="http://stores.ebay.com.au/Alchemy-Suiting/About-Us.html">About Us</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Alchemy-Suiting/Shipping.html">Shipping</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Alchemy-Suiting/Returns.html">Returns</a></li>');
document.write('<li><a href="http://stores.ebay.com.au/Alchemy-Suiting/Feedbacks.html">Feedbacks</a></li>');
document.write('<li><a href="http://contact.ebay.com/ws/eBayISAPI.dll?FindAnswers&frm=284&&requested=alchemy_suiting&guest=1">Contact Us</a></li>');
document.write('</ul>');
