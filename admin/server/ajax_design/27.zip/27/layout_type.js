var layout_type = 1;
