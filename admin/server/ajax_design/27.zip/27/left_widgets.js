var left_widgets = ["store categories","popular categories","image & video slider"];
