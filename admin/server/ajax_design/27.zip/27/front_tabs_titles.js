var  tab_titles = '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tabs widget is active but has not items to show.';
