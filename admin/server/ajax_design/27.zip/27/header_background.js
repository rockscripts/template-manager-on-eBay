document.write('<img src="http://fileshosting.rockscripts.org/files/store_design/general_images/27//header_home-%281%29.png"  class="img-responsive">');
