var twiter_url = "https://twitter.com/alchemy_suiting";
var facebook_url = "https://facebook.com/alchemysuiting ";
var youtube_url = "https://youtube.com/";
var printerest_url = "https://pinterest.com/";
var linkedin_url = "";
var google_url = "";
var delicious_url = "";
