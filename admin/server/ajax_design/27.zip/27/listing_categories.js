var  dynamic_categories = '<ul class=\'vertical blue\'>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/custom-suits-/_i.html?_fsub=11522889018">Custom suits</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/custom-shirts-/_i.html?_fsub=11522890018">Custom shirts</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/custom-coats-/_i.html?_fsub=11522891018">Custom coats</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/ties-/_i.html?_fsub=11522892018">Ties</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/pocket-squares-/_i.html?_fsub=11522893018">Pocket squares</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/cufflinks-/_i.html?_fsub=11522894018">Cufflinks</a></li>'+
'<li><a href="http://stores.ebay.com.au/AlchemySuiting/other-/_i.html?_fsub=1">Other</a></li>'+
'</ul>';
