var center_widgets = false;
