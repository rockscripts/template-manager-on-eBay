var left_widgets = ["store categories","advertising","popular categories"];
