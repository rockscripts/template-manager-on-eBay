var  slider_images = '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Slider widget is active but has not images or videos to show.';
