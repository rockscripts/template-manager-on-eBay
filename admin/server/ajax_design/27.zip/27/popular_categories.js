var  popoular_categories = '<div class="rc-box">'+
'<div class="rc-image">'+
'<a title="Custom Suits" href="http://stores.ebay.com.au/AlchemySuiting/custom-suits-/_i.html?_fsub=11522889018">'+
'<img src="http://fileshosting.rockscripts.org/files/store_design/popular_categories/27//custom-suits.jpg" alt="[NAME]"/>'+
'</a>'+
'</div>'+
'<div class="rc-name">'+
'<span>Custom Suits</span>'+
'</div>'+
'</div>';
