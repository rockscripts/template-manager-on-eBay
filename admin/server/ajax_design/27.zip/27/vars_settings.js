var store_name = "Alchemy_Suiting";
var store_id = "alchemy_suiting";
var store_url = "http://stores.ebay.com/alchemysuiting";
var store_phone = "";
var currency = "AUD";
var hosting_url = "http://hosting.rockscripts.org/27";
