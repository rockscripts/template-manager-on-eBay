var  front_advertisings =  '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Advertisings is active but has not items to show.';
