var center_widgets = [];
