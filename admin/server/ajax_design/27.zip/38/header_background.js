document.write('<img src="http://fileshosting.rockscripts.org/files/default_images/header_home.png"  class="img-responsive">');
