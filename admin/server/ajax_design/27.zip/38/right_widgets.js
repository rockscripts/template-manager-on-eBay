var right_widgets = [];
