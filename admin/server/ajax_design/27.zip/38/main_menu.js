document.write('<ul class="nav navbar-nav"><li><a href="javascript:void(0);" class="alert"><i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your main menu is empty</a></li></ul>');
