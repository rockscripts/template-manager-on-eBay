var  featured_listings = '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Advertisings widget is active but has not items to show.';
