var  dynamic_categories = '<ul class="vertical blue">'+
'<li><a href="http://stores.ebay.com/rockscripts/other-/_i.html?_fsub=1">Other</a></li>'+
'<li><a href="http://stores.ebay.com/rockscripts/ebay-design-/_i.html?_fsub=5691058014">Ebay design</a></li>'+
'</ul>';
