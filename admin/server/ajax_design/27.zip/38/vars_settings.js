var store_name = "rockscripts";
var store_id = "rockscripts";
var store_url = "http://stores.ebay.co.uk/rockscripts";
var store_phone = "";
var currency = "USD";
var hosting_url = "http://hosting.rockscripts.org/38";
