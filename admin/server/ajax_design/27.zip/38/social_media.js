var twiter_url = "";
var facebook_url = "";
var youtube_url = "";
var printerest_url = "";
var linkedin_url = "";
var google_url = "";
var delicious_url = "";
