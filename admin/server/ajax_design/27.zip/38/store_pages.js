var pages_array = new Array();
object = {'title':'Feedback','url':'http://stores.ebay.com/rockscripts/Feedback.html','content':'<p>	feedback test</p>'};
pages_array.push(object);
object = {'title':'Contact Us','url':'http://stores.ebay.com/rockscripts/Contact-Us.html','content':'<p>	<a href="http://stores.ebay.com/ws/BayISAPI.dll?SignIn&amp;UsingSSL=1&amp;pUserId=&amp;co_partnerId=2&amp;siteid=3&amp;ru=http%3A%2F%2Fcontact.ebay.com%2Fws%2FeBayISAPI.dll%3FFindAnswers%26frm%3D284%26%26requested%3Deleniesstore2010%26guest%3D1&amp;pageType=5410">Contact Us</a></p>'};
pages_array.push(object);
object = {'title':'Shipping and Returns','url':'http://stores.ebay.com/rockscripts/Shipping-and-Returns.html','content':'<p>	Shipping and Returns content</p>'};
pages_array.push(object);
object = {'title':'About Us','url':'http://stores.ebay.com/rockscripts/About-Us.html','content':'<p>	About Us test</p>'};
pages_array.push(object);
