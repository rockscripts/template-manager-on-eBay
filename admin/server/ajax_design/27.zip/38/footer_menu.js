document.write('<ul class="nav navbar-nav"><li style="color:black!important;"><i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your footer menu is empty</li></ul>');
