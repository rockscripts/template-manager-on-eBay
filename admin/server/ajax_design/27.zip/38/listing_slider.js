var  slider_images = '<i class="alert-icon"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Image & Video slider widget is active but has not items to show.';
