var hosting_url = hosting_client;
var social_media_buttons_parts = '<a class="clean-css social-button facebook-link" href="#">'+
'<img src="'+hosting_url+'/assets/images/facebook.png"/>'+
'</a>'+
'<a class="clean-css twiter-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/twitter.png"/>'+
'</a>'+
'<a class="clean-css youtube-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/youtube.png"/>'+
'</a>'+
'<a class="clean-css pinterest-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/pinterest.png"/>'+
'</a>'+
'<a class="clean-css delicious-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/delicious.png"/>'+
'</a>'+
'<a class="clean-css linkedin-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/linkedin.png"/>'+
'</a>'+
'<a class="clean-css google-link social-button" href="#">'+
'<img src="'+hosting_url+'/assets/images/google.png"/>'+
'</a>';