var hosting_url = hosting_client;
var social_media_buttons_parts = '<a class="clean-css social-button facebook-link" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css twiter-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css youtube-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css pinterest-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css delicious-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css linkedin-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>'+
'<a class="clean-css google-link social-button" href="#">'+
'<div class="button-social"></div>'+
'</a>';